#!/bin/sh
exec ../../../tools/lazres ../lazsqldbrest_images.inc @filelist.txt

