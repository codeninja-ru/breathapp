The simple examples were moved to the FPC sources.
See <fpcsrc>/packages/fcl-web/examples

The rest server example is not usable without lazarus support, so it stays
here.


