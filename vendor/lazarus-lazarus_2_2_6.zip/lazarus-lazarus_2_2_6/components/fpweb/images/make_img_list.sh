#!/bin/sh

if [ -f fpweb_images.inc ]; then
  rm fpweb_images.inc
fi  
../../../tools/lazres fpweb_images.inc HTMLList.png quick_table.png tag_dd.png  tag_dl.png  tag_dt.png  tag_li.png  tag_ol.png  tag_ul.png tag_table_body.png  tag_table_row.png  tag_tbody.png tag_td.png tag_tr.png tag_table_data.png tag_h1.png tag_h2.png tag_h3.png tag_h4.png tag_h5.png HTMLForm.png lineedit.png reset.png submit.png tag_image.png tag_br.png tag_comm.png tag_hr.png color-picker.png div_center.png div_justify.png div_left.png div_right.png tag_bold.png tag_i.png tag_u.png tag_nbsp.png button.png check.png radio.png select.png tag_a.png tag_attribute.png tag_element.png tag_sub.png tag_sup.png tag_font.png tag_pre.png tfphttpwebclient.png tfphttpclient.png  tfphttpserver.png
