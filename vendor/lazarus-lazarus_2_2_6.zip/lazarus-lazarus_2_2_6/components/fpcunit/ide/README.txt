Package fpcunit

This package is a designtime package for the Lazarus IDE.
It adds a new project type and a new unit type to the IDE.

This unit adds a new project type and a new unit type to the IDE.
    New Project Type:
      FPCUnit Application - A Free Pascal program for FPCUnit tests.
      
    New Unit Type:
      FPCUnit test - A unit with a unit test.



