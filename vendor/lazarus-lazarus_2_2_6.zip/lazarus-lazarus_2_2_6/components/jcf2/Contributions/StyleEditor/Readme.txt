Standalone Style Editor of JEDI Code Format 1.0

Introduction

When I develop Code Beautifier Collection 6.0 (code named GrapeVine), I found that a standalone Style file editor is necessary even though Anthony creates a bunch of projects already (commandline, GUI, IDE experts, and Notepad).

I rip a few files out of Notepad project, so a simple editor is crearted. It meets all Code Beautifier Collection reu=quirements,

1. standalone.
2. it only edits the JCFSettings.cfg file in the same folder (never touch the one defined in registry).

Source File

The zip package contains a folder named Style. Extract it and place in JCF source code root folder (in the same level of Commandline). Then open the project in Delphi 2007 (JCL and JVCL must be installed).

Limitation

This project is created for Code Beautifier Collection only.

License

This project is licensed under MPL, the same as original JCF.

Li Yang
http://lextm.blogspot.com
Code Beautifier Collection
http://code.google.com/p/lextudio