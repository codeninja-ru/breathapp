this test application makes it more simple to debug sourceprinter.pas. Instead of recompiling lazarus each time you just recompile this app.

Darius Blaszijk (dhkblaszijk@zeelandnet.nl)