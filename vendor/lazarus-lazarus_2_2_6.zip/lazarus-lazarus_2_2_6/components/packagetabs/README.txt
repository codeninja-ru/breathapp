IDE add-on:
When installed, this package replaces source editor tabs/pages with buttons sorted by package and name.

Author: Ondrej Pokorny

Documentation:
http://wiki.lazarus.freepascal.org/Package_Tabs
