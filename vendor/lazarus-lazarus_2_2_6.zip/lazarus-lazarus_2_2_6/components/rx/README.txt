The files in this folder have been move to the rx project on 
Lazarus Code and Component Repository on SourceForge, 
(https://sourceforge.net/p/lazarus-ccr/svn/HEAD/tree/components/rx/trunk/rx_laz/)
