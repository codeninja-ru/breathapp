Output directory of package SQLiteLaz

