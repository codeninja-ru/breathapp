#!/usr/bin/env bash
../../../tools/lazres ../pg_images.res @pg_images_list.txt
