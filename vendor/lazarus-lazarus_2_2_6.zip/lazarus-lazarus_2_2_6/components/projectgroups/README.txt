IDE add-on for Project Groups.
Project Groups allows to build groups of projects with a few mouse clicks.

Original code from Michael Van Canneyt.

Author: Mattias Gaertner mattias@freepascal.org

Documentation:
http://wiki.lazarus.freepascal.org/Project_Groups
