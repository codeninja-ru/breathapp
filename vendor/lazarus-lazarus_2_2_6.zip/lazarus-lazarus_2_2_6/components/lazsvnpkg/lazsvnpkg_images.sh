#!/usr/bin/env bash
../../tools/lazres lazsvnpkg_images.res @lazsvnpkg_images_list.txt
