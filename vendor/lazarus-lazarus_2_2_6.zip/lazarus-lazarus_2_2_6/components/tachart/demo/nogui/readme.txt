-------------------------------------------------------------------------------
NOTE TO WINDOWS USERS
-------------------------------------------------------------------------------

When this demo is compiled with FPC 3.2.0 or later it is required to have the 
freetype.dll in the current directory (or in the system directory).

If not on your system already, you can download a pre-compiled binary of the 
dll from https://github.com/ubawurinna/freetype-windows-binaries

Please choose the correct version according to the bitness of your application.
