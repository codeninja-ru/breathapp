How to update the image resources:

../../../tools/lazres ../syneditlazdsgn.lrs @syneditlazdsgn.txt

