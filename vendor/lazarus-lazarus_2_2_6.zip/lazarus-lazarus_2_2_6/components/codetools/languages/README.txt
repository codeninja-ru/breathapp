The <lazarusdir>/components/codetools/languages directory contains all the stuff
for CodeTools internationalization.

All text and messages used in the CodeTools should be placed into the
codetoolsstrconsts.pas unit.