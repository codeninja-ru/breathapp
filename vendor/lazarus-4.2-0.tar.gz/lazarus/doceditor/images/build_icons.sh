#!/bin/sh
../../tools/lazres ../icons.lrs Insert_16N.bmp Delete_16N.bmp Edit_16N.bmp node_edit.xpm node_finished.xpm node_modified.xpm node_new.xpm
