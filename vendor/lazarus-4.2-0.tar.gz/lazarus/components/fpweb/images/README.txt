How to update the image resources:

../../../tools/lazres ../fpweb_images.res @fpweb_images_list.txt

