#!/bin/sh
../../../../../../tools/lazres ../lrspreadsheetexp.res @img.txt
