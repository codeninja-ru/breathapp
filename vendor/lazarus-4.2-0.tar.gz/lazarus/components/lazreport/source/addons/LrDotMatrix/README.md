# LrDotMatrix
Component for dot matrix printing with LazReport

A report sent to a dot-matrix printer will be printed very slowly.
LrDotMatrix allows the creation of special reports intended for dot-matrix printers, where only standard font symbols and no graphic elements are output; this results in a faster printing speed.



<img alt="Logo" src="https://github.com/groupsc10/LrDotMatrix/blob/master/image/dot.png">
