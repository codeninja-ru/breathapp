Package EducationLaz
====================

This package helps to setup the IDE for courses, training and education.
Install this package in the IDE and setup it in
  Environment / Options .. / Education

The documentation can be found here:
http://wiki.lazarus.freepascal.org/Lazarus_for_education

