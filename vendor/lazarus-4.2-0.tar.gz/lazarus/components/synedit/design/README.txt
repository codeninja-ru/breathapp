How to update the image resources:

../../../tools/lazres syneditlazdsgn.res @syneditlazdsgn.txt

