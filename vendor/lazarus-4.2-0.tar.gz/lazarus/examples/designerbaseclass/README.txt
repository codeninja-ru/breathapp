This demonstrates how to add a new component base class for the designer.

Normally the IDE knows only TForm and TDataModule as base classes.
All components that can be designed in the IDE must descend form one of these
classes.

Quick start:
Install the package DesignBaseClassDemoPkg in the IDE and restart it.

Then open the project example/demo1.lpi

