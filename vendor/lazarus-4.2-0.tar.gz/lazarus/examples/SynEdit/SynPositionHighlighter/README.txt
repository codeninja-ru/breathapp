Example for SynEdit's Highlighter: TSynPositionHighlighter
(SynEdit is the editor used by the IDE)

TSynPositionHighlighter allows one to highlight text at one or more fixed position(s).
For example, it can be used to highlight the first 3 letters of the 2nd line of text, in a specific color.
