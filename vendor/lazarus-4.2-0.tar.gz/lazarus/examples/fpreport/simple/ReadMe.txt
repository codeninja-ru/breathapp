If the programm doesn't compile or run, look if you have the
correct freetype-6.dll/.so and zlib1.dll/.so installed or copied in the directory.

AF 2018

