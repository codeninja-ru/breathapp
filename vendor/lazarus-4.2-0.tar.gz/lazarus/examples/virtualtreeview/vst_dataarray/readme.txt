This is an "official" VirtualTreeView demo project ported to and optimized for Lazarus. 
More samples can be found at https://github.com/blikblum/VirtualTreeView-Lazarus/tree/lazarus-v5/Demos.