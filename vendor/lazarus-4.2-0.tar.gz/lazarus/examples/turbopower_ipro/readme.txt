This directory contains two programs to test the package 
TurboPower Internet Professional. 

(1) tpiproexample: Basic function to display and print a html page.
    Requires that the define HTML_Print is activated.
    
(2) tpiprohtmltree: Displays the hierarchy of html nodes of a html document
    in a treeview.
    Requires that the define HTML_RTTI is activated.
    
Both project require the component turbopoweripro.lpk located in directory 
$LazarusDir/components/turbopower_ipro.
   

