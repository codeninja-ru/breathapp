This example is a design time package.
When installed it registers a new menu item in the IDE, which shows all the
IDE menus as treeview.

