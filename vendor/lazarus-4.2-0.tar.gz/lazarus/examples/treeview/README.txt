
This demo was written by Andre .v.d. Merwe and marked public domain.
Quickly converted to Lazarus and FPC by Tom Lisjac <vlx@users.sourceforge.net>

The original source and an *excellent* tutorial on the TTreeview
component can be found here:

https://web.archive.org/web/20180423180227/http://users.iafrica.com/d/da/dart/Delphi/TTreeView/TreeView.html

(The original site at http://users.iafrica.com/d/da/dart/Delphi/TTreeView/TreeView.html
is not available any more).
