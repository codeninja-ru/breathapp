Demonstrates the usage of TToolBars inside a TCoolBar.

Contains a CoolBar with five FixedSize bands with ToolBars.
It can be configured (orientation, visibility, size of buttons).
This configuration is stored to INI file and is restored when you run demo again.

Author: Vojtech Cihak
