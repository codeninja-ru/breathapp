This directory contains the sources of the lazarus package registration
interface.
