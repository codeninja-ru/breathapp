This directory contains test written with fpcunit. It contains two projects: 
* runtests.lpi for running the tests using the fpcunit console runner.
* runtestsgui.lpi for running the tests using the fpcunit gui runner.

=== Project runtests.lpi =======================================================

Build it and run it in a terminal without parameters will give you a list of
parameters:
./runtests


=== Project runtestsgui.lpi ====================================================

Build it and run.
On windows it will run the programs and interact with them using autohotkey.
Currently this is only used with the hello example.


