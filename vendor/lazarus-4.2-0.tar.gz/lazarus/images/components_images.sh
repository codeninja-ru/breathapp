#!/usr/bin/env bash
../tools/lazres components_images.res @components_images_list.txt
