#!/usr/bin/env bash
../tools/lazres bookmark.res @bookmark_list.txt
