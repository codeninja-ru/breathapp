#!/usr/bin/env bash
../tools/lazres laz_images.res @laz_images_list.txt
