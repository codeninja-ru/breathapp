The CHMMaker program lets you create CHM help files.

Quick start:

Compile and run chmmaker.lpi
Open the help file project "example/example.hfp" via the menu File / Open
Click the "Compile" button.
This will create "example.chm", which can be shown by any chm viewer, including "lhelp", which you can find in lazarus/components/chmhelp/lhelp/.
