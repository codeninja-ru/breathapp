The icon in this folder is provided by Roland Hahn. 
It can be used freely without any restrictions.