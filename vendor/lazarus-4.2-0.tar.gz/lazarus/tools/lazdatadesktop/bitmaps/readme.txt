The images in this folder are used in the imagelists in the dmImages datamodule
and in the dicteditor resource. They were kindly provided by 
Roland Hahn (https://www.rhsoft.de).

Additional images not found here, were taken from the "images/general_purpose" 
folder of the Lazarus installation, also created by Roland Hahn.

License for the images: 
Creative Commons CC0 1.0 Universal
https://creativecommons.org/publicdomain/zero/1.0/
(freely available, no restrictions in usage)