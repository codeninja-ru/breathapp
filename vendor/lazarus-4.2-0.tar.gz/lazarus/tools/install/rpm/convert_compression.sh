#!/bin/sh
rpmrebuild -npD '_binary_payload w9.bzdio'
