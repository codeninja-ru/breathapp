#!/usr/bin/env bash

RPMDir=`rpm --eval "%{_topdir}"`

echo $RPMDir

# end.

