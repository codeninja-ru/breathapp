#!/usr/bin/env bash
#
# Author: Mattias Gaertner

echo "Skipping one rpm build step ..."

# end.

