#!/bin/bash

./create_fpc_deb.sh fpc-src $@

# end.
