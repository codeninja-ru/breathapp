This tool allows to move translations between .po files. 
It can also find potential duplicate entries.

All Sources are licensed under LGPL v2 with linking exception (same as LCL).
